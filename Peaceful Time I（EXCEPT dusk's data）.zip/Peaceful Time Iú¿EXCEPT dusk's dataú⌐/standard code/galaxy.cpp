#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
typedef double DB;
const int MAXL=20;
const int MAXN=10;
LL L,R,pw[MAXL],opw[MAXL];
int T,d,x,y,l1,l2,r1,r2;
LL f[MAXL][MAXN],ans,ans1,ans2;
void clear_d(){
	x=y=l1=l2=r1=r2=ans=ans1=ans2=0;
	memset(f,0,sizeof(f));
	memset(pw,0,sizeof(pw)),memset(opw,0,sizeof(opw));
}
int log(LL x,int dx){
	int cnt=0;
	while (x) x/=dx,cnt++;
	return cnt-1;
}
LL odxcalc(LL x,int l,int dx){
	x/=10; int t=l-1; LL res=0,s=x;
	while (t>=2)
		res=res+(s%10)*pw[l-t-1],t--,s/=10;
	return res;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d",&T);
	while (T--){
		scanf("%lld%lld%d",&L,&R,&d);
		clear_d();
		opw[0]=pw[0]=1,x=log(L,10)+1,y=log(R,10)+1;
		for (int i=1;i<=18;i++)
			pw[i]=pw[i-1]*(LL)d,opw[i]=opw[i-1]*10LL;
		l1=floor((DB)L/(DB)opw[x-1]),r1=floor((DB)R/(DB)opw[y-1]);
		l2=L%10LL,r2=R%10LL;
		for (int i=1;i<=18;i++)
			for (int j=1;j<=d-1;j++)
				f[i][j]=pw[max(i-2,0)];
		if (l1<=l2){
			for (int i=min(l1,l2)+1;i<=d-1;i++) ans1+=f[x][i];
			ans1+=(pw[max(0,x-2)]-odxcalc(L,x,d)-1);
			if (l1==l2) ans1++;
		}
		else{
			for (int i=max(l1,l2)+1;i<=d-1;i++) ans1+=f[x][i];
			ans1+=(pw[max(0,x-2)]-odxcalc(L,x,d));
		}
		if (r1>=r2){
			for (int i=1;i<=max(r1,r2)-1;i++) ans2+=f[y][i];
			ans2+=odxcalc(R,y,d);
			if (r1==r2) ans2++;
		}
		else{
			for (int i=1;i<=min(r1,r2)-1;i++) ans2+=f[y][i];
			ans2+=(odxcalc(R,y,d)+1);
		}
		for (int i=x+1;i<=y-1;i++)
			for (int j=1;j<=d-1;j++) ans+=f[i][j];
		ans+=(ans1+ans2);
		if (x==y){
			LL tmp=0;
			for (int i=1;i<=d-1;i++) tmp+=f[x][i];
			ans=ans1+ans2-tmp;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
