#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int MAXN=100005;
int N,r,P,M,K,L,R,a[MAXN],cnt[MAXN];
LL f[MAXN],g[MAXN],tot;
struct node{
	LL pos,cst;
}b[MAXN];
priority_queue<LL> Q;
bool cmp(node p,node q){
	return p.pos<q.pos;
}
void move(int l,int r){
	while (L>l) tot+=(cnt[a[--L]]++);
	while (L<l) tot-=(--cnt[a[L++]]);
	while (R>r) tot-=(--cnt[a[R--]]);
	while (R<r) tot+=(cnt[a[++R]]++);
}
void solve(int l,int r,int sl,int sr){
	if (sl>sr) return;
	int md=(sl+sr)>>1,p;
	LL mx=1e18;
	for (int i=l;i<=r;i++){
		move(i+1,md);
		if (f[i]+tot<mx) mx=f[i]+tot,p=i;
	}
	g[md]=mx,solve(l,p,sl,md-1),solve(p,r,md+1,sr);
}
void sightsee1(){
	M=P; LL curt=0; int ans=0,tcnt=0;
	for (int i=1;i<=N;i++)
		scanf("%lld%lld",&b[i].pos,&b[i].cst);
	sort(b+1,b+N+1,cmp);
	for (int i=1;i<=N;i++){
		curt+=(b[i].pos-b[i-1].pos);
		curt+=b[i].cst;
		Q.push(b[i].cst),tcnt++;
		if (curt<=M) ans=max(ans,tcnt);
		else{
			while (curt>M&&!Q.empty()){
				LL x=Q.top(); Q.pop();
				curt-=x,tcnt--;
			}
			ans=max(ans,tcnt);
		}
	}
	printf("%d",ans);
}
void sightsee2(){
	K=P;
	for (int i=1;i<=N;i++) scanf("%d",&a[i]);
	for (int i=1;i<=N;i++) scanf("%d",&a[i]);
	for (int i=1;i<=N;i++) f[i]=1e18;
	while (K--){
		memset(cnt,0,sizeof(cnt));
		tot=R=0,L=1,solve(0,N-1,1,N);
		for (int i=1;i<=N;i++) f[i]=g[i],g[i]=0;
	}
	printf("%d",f[N]);
}
int main(){
	freopen("blossom.in","r",stdin);
	freopen("blossom.out","w",stdout);
	scanf("%d%d%d",&N,&r,&P);
	if (r==1) sightsee1();
	else sightsee2();
	return 0;
}
