#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int MAXN=(2e5+5);
int N,M,K,p,x,y,w,d[MAXN],dgr[MAXN],f[MAXN];
int fst1[MAXN],nxt1[MAXN],to1[MAXN],tot1;
int fst2[MAXN],nxt2[MAXN],to2[MAXN],tot2;
int s[MAXN],Ans[MAXN];
LL S1,S2;
stack<int> sta;
void add1(int x,int y){
	to1[++tot1]=y,nxt1[tot1]=fst1[x],fst1[x]=tot1;
}
void add2(int x,int y){
	to2[++tot2]=y,nxt2[tot2]=fst2[x],fst2[x]=tot2;
	to2[++tot2]=x,nxt2[tot2]=fst2[y],fst2[y]=tot2;
}
struct edge{
	int x,y,w;
}a[MAXN];
int fa[MAXN];
edge ans[MAXN];
bool cmp(edge p,edge q){
    if (p.w==q.w&&p.x==q.x) return p.y<q.y;
    else if (p.w==q.w) return p.x<q.x;
    else return p.w<q.w;
}
int fnd(int x){
    if (fa[x]!=x) fa[x]=fnd(fa[x]);
    return fa[x];
}
void Kruscal(){
    for (int i=1;i<=N;i++) fa[i]=i;
    int cnt=0;
    sort(a+1,a+M+1,cmp);
    for (int i=1;i<=M;i++){
        int x=fnd(a[i].x),y=fnd(a[i].y);
        if (x!=y) fa[y]=x,ans[++cnt]=(edge)a[i];
        if (cnt==N-1) break;
    }
}
int dfs1(int x){
	int tmp=0;
	for (int i=fst2[x];i;i=nxt2[i])
		if (to2[i]!=fa[x]) fa[to2[i]]=x,tmp+=dfs1(to2[i]);
	return s[x]=(tmp+1);
}
void dfs2(int x){
	int tmp,tmp1=s[x],tmp2=(s[x]-1)*(s[x]-1);
	int num[MAXN],pos=0;
	for (int i=fst2[x];i;i=nxt2[i])
		if (to2[i]!=fa[x]) num[++pos]=to2[i];
	for (int i=1;i<=pos;i++)
		tmp2-=s[num[i]]*s[num[i]];
	tmp2/=2,tmp=tmp1+tmp2,Ans[x]=(tmp*2-1);
}
int main(){
	freopen("dusk.in","r",stdin);
	freopen("dusk.out","w",stdout);
	scanf("%d%d%d",&N,&M,&K);
	for (int i=1;i<=N;i++) scanf("%d",&d[i]);
	for (int i=1;i<=M;i++){
		scanf("%d%d%d",&x,&y,&w);
		add1(x,y),dgr[y]++;
		a[i]=(edge){x,y,w};
	}
	for (int i=1;i<=N;i++)
		if (!dgr[i]) f[i]=1,sta.push(i);
	while (!sta.empty()){
		int u=sta.top(); sta.pop();
		for (int i=fst1[u];i;i=nxt1[i]){
			int v=to1[i]; dgr[v]--;
			if (!dgr[v]) sta.push(v);
			f[v]=max(f[v],f[u]+1);
		}
	}
	for (int i=1;i<=N;i++) S1^=(LL)(f[i]+d[i]);
	Kruscal(); memset(fa,0,sizeof(fa));
	for (int i=1;i<=N-1;i++) add2(ans[i].x,ans[i].y);
	dfs1(1);
	for (int i=1;i<=N;i++) dfs2(i);
	for (int i=1;i<=K;i++)
		scanf("%d",&p),S2^=(LL)Ans[p];
	printf("%lld %lld",S1,S2);
	return 0;
}
